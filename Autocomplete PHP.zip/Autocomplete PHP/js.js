$('.load-drugs-insulin').autocomplete({
  source: function( request, response ) {
	$.ajax({
	  type: "GET",
	  url: baseUrl + "patients/visit/get_insulin",
	  dataType: "json",
	  data: {
		q: request.term
	  },
	  success: function( data ) {
		response( data.content);
	  }
	});
  },
  select: function (event, ui) {
			$(this).val(ui.item.label); // display the selected text
			console.log(ui.item.label);
			console.log(ui.item.value);
			//$("#txtAllowSearchID").val(ui.item.value); // save selected id to hidden input
			return false;
  },
  minLength: 1,
  open: function() {
	$( this ).removeClass( "ui-corner-all" ).addClass( "ui-corner-top" );
  },
  close: function() {
	$( this ).removeClass( "ui-corner-top" ).addClass( "ui-corner-all" );
  }
});