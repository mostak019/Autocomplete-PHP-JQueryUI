<?php
public function get_insulin()
{
	$term = html_escape($this->input->get('q'));
	$get_drugs = $this->Visit_model->get_insulin($term);
	$content = array();
	foreach($get_drugs as $drug):
		$content[] = array("label" => $drug['insuline_brand'], "value" => intval($drug['insuline_id']));
	endforeach;
	echo json_encode(array('content' => $content));
	exit;
}